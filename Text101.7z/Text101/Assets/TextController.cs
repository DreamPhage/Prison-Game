﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class TextController : MonoBehaviour {

	public Text text;
	
	private enum States {
		cell, apple, bars_0, bars_1, bed_0, bed_1, broken, corpse_0, lock_0, corpse_1, lock_1, cooridor_0,
		forward_0, forward_1, forward_2, torch_0, torch_1, upstairs, upstairs_1, downstairs_0, downstairs_1, 
		freedom, grease_fire_0, grease_fire_1, grease_fire_2, key1_key2, left, right
		};
	private States myState;
	
	// Use this for initialization
	void Start () {
		myState = States.cell;
	}
	
	// Update is called once per frame
	void Update () {
		print (myState);
		if (myState == States.cell) {
			cell();
		} else if (myState == States.corpse_0) {
			corpse_0();
		} else if (myState == States.corpse_1) {
			corpse_1();
		} else if (myState == States.bars_0) {
			bars_0();
		} else if (myState == States.bars_1) {
			bars_1();
		} else if (myState == States.lock_0) {
			lock_0();
		} else if (myState == States.lock_1) {
			lock_1();
		} else if (myState == States.broken) {
			broken();
		} else if (myState == States.cooridor_0) {
			cooridor_0();
		} else if (myState == States.forward_0) {
			forward_0();
		} else if (myState == States.upstairs) {
			upstairs();
		} else if (myState == States.downstairs_0) {
			downstairs_0();
		} else if (myState == States.downstairs_1) {
			downstairs_1();
		} else if (myState == States.grease_fire_0) {
			grease_fire_0();
		} else if (myState == States.grease_fire_1) {
			grease_fire_1();
		} else if (myState == States.grease_fire_2) {
			grease_fire_2();
		} else if (myState == States.left) {
			left();
		} else if (myState == States.right) {
			right();
		}
	}
	
	void cell () {
		text.text = "You wake up naked in a prison cell. It stinks. After your eyes adjust to the dim light " +
					"you notice a corpse huddled against the bars of the cell. You have never seen something " +
					"so disgusting and so terrifying. You want to get out, but the cell is locked from outside.\n\n" +
					"Press B to Inspect Bars, C to Inspect Corpse, or L to Inspect Lock";
		if(Input.GetKeyDown(KeyCode.C)) {
			myState = States.corpse_0;
		} else if(Input.GetKeyDown(KeyCode.B)) {
			myState = States.bars_0;
		} else if(Input.GetKeyDown(KeyCode.L)) {
				myState = States.lock_0;
		}
	}
	
	void corpse_0 () {
		text.text = "The corpse is fairly fresh. An old man clutching his stomach. Blood pooled and dried around " +
					"him. There's something shiny in his wound...\n\n" +
					"Press I to Inspect, Press R to Return to Start";
		if(Input.GetKeyDown(KeyCode.I)) {
			myState = States.corpse_1;
		} else if(Input.GetKeyDown(KeyCode.R)){
			myState = States.cell;
		}
	}
	
	void corpse_1 () {
		text.text = "You gently move the man's hands away from his stomach. There's a shiv lodged just below " + 
					"the navel. You pull it. The blade comes free. \n\n" +
					"Press B to Inspect Bars, L to Inspect Lock, or R to Return to Start";
		if (Input.GetKeyDown(KeyCode.B)) {
			myState = States.bars_1;
		} else if(Input.GetKeyDown(KeyCode.L)){
			myState = States.lock_1;
		} else if(Input.GetKeyDown(KeyCode.R)){
			myState = States.cell;
		}
	}
	
	void bars_0 () {
		text.text = "You walk over to the cold steel bars. They are solid. No weak points here.\n\n" + 
					"Press R to Return to Start, or C to Inspect Corpse";
		if (Input.GetKeyDown(KeyCode.R)) {
			myState = States.cell;
		} else if(Input.GetKeyDown(KeyCode.C)){
			myState = States.corpse_0;
		}
	}

	void bars_1 () {
		text.text = "You walk over to the cold steel bars. They are solid. No weak points here.\n\n" + 
					"Press S to use the Shiv, or R to Return to Start";
		if (Input.GetKeyDown(KeyCode.R)) {
			myState = States.cell;
		} else if(Input.GetKeyDown(KeyCode.S)){
			myState = States.broken;
		}
	}
	
	void broken () {
		text.text = "You stab the bars with your shiv as hard as you can. The shiv is now broken. " + 
					"How will you proceed?\n\n" + 
					"Press L to Inspect Lock, or R to Return to Start";
		if (Input.GetKeyDown(KeyCode.R)) {
			myState = States.cell;
		} else if(Input.GetKeyDown(KeyCode.L)){
			myState = States.lock_0;
		}
	}
	
	void lock_0 () {
		text.text = "You walk over to the lock. Upon inspection you find you have nothing to unlock " + 
					"it with. What will you do?\n\n" + 
					"Press R to Return to Start";
		if (Input.GetKeyDown(KeyCode.R)) {
			myState = States.cell;
		} else if(Input.GetKeyDown(KeyCode.L)){
			myState = States.lock_0;
		}
	}
	
	void lock_1 () {
		text.text = "You walk over to the lock. Upon inspection you find your shiv will fit it " + 
					"nicely. What will you do?\n\n" + 
					"Press S to Use Shiv, Press R to Return to Start";
		if (Input.GetKeyDown(KeyCode.R)) {
			myState = States.cell;
		} else if(Input.GetKeyDown(KeyCode.S)){
			myState = States.cooridor_0;
		}
	}
	
	void cooridor_0 () {
		text.text = "You slowly press the tip of the blade into the lock. After turning the " + 
					"shiv for a while you here a click. You press against the cell door... " +
					"You walk through the next door and enter a cooridor. There are stairs " +
					"leading up, stairs leading down, and a wooden door ahead.\n\n" +
					"Press U for Up, D for Down, or F to go Forward";
		if (Input.GetKeyDown(KeyCode.U)) {
			myState = States.upstairs;
		} else if(Input.GetKeyDown(KeyCode.D)){
			myState = States.downstairs_0;
		} else if(Input.GetKeyDown(KeyCode.F)){
			myState = States.forward_0;
		}
	}
	
	void downstairs_0 () {
		text.text = "You slowly work your way downstairs. There's a heavy breathing " + 
					"sound that gets louder as you go. It doesn't sound human and " +
					"it doesn't sound like any animal you've ever heard. "+
					"You can continue down or go upstairs. What will you do?\n\n" +
					"Press D for Downstairs, or U for Upstairs";
		if (Input.GetKeyDown(KeyCode.U)) {
			myState = States.upstairs;
		} else if(Input.GetKeyDown(KeyCode.D)){
			myState = States.downstairs_1;
		}
	}
	
	void downstairs_1 () {
		text.text = "You crouch low and take shallow steps. You're nearly at the bottom. " + 
					"Just before you take the next step the thing roars. You lose your  " +
					"balance and fall thudding down the stairs until you reach " +
					"the bottom.\n\n" +
					"At first you see nothing but the black darkness. And then..." +
					"The creature opens its baleful green glowing eyes. By the light " +
					"of his eyes you can see the general shape of his hulking head " +
					"and his long sharp teeth. You are going to die.\n\n" +
					"Press R to Restart";
		if (Input.GetKeyDown(KeyCode.R)) {
			myState = States.cell;
		}
	}
	
	void forward_0 () {
		text.text = "You walk down the corridor and stand in front of the wooden door. " + 
					"There's no keyhole in the handle, and you jiggle it a bit. " +
					"It's locked. What do you do?\n\n" +
					"Press U for Upstairs, D for Downstairs";
		if (Input.GetKeyDown(KeyCode.U)) {
			myState = States.upstairs;
		} else if(Input.GetKeyDown(KeyCode.D)){
			myState = States.downstairs_0;
		}
	}
	
	void upstairs () {
		text.text = "You creep up the stairs. They wind upward toward a flickering light." + 
					"The stairs end at a servants bedchamber. " +
					"There are a few items of note: a straw bed, a glowing torch, and an " +
					"an apple. What do you do?\n\n" +
					"Press B to Inspect the Bed, T to Inspect the Torch, or A to eat the Apple ";
		if (Input.GetKeyDown(KeyCode.B)) {
			myState = States.bed_0;
		} else if(Input.GetKeyDown(KeyCode.T)){
			myState = States.torch_0;
		} else if(Input.GetKeyDown(KeyCode.A)){
			myState = States.apple;
		}
	}
	
	void bed_0 () {
		text.text = "You rifle through the straw searching for anything useful." + 
					"Something squishy meets your fingers, and you hurriedly push " +
					"the straw aside. You've found a container of grease" +
					"What do you do?\n\n" +
					"Press R to Return, Press T to Inspect the Torch, or A to eat the Apple ";
		if (Input.GetKeyDown(KeyCode.R)) {
			myState = States.bed_1;
		} else if(Input.GetKeyDown(KeyCode.T)){
			myState = States.grease_fire_0;
		} else if(Input.GetKeyDown(KeyCode.A)){
			myState = States.apple;
		}
	}
	
	void bed_1 () {
		text.text = "You walk back down to the corridor with your grease in hand." + 
					"What do you do?\n\n" +
					"Press U to go Upstairs, Press D to go Downstairs, or F to go Forward ";
		if (Input.GetKeyDown(KeyCode.U)) {
			myState = States.upstairs;
		} else if(Input.GetKeyDown(KeyCode.D)){
			myState = States.downstairs_0;
		} else if(Input.GetKeyDown(KeyCode.F)){
			myState = States.forward_1;
		}
	}
		
	void torch_0 () {
		text.text = "You remove the torch from it's holder on the wall. The flames " + 
					"crackle and sputter as you move away from the wall." +
					"What will you do?\n\n" +
					"Press R to Return, Press B to Inspect the Bed, or A to eat the Apple ";
		if (Input.GetKeyDown(KeyCode.R)) {
			myState = States.torch_1;
		} else if(Input.GetKeyDown(KeyCode.B)){
			myState = States.grease_fire_1;
		} else if(Input.GetKeyDown(KeyCode.A)){
			myState = States.apple;
		}
	}
	
	void torch_1 () {
		text.text = "You return to the cooridor, torch held before you." + 
					"What do you do?\n\n" +
					"Press U to go Upstairs, Press D to go Downstairs, or F to go Forward ";
		if (Input.GetKeyDown(KeyCode.U)) {
			myState = States.upstairs;
		} else if(Input.GetKeyDown(KeyCode.D)){
			myState = States.downstairs_0;
		} else if(Input.GetKeyDown(KeyCode.F)){
			myState = States.forward_2;
		}
	}
		
	void apple () {
		text.text = "You pick up the apple and brush it off. It looks edible. So you " + 
					"eat it. It will do for now." +
					"What will you do?\n\n" +
					"Press B to Inspect the Bed, Press T to Inspect the Torch ";
		if (Input.GetKeyDown(KeyCode.B)) {
			myState = States.bed_0;
		} else if(Input.GetKeyDown(KeyCode.T)){
			myState = States.torch_0;
		}
	}
	
	void grease_fire_0 () {
		text.text = "You remove the torch from it's holder on the wall. The flames " + 
					"crackle and sputter as you move away from the wall. With this " +
					"and the grease you could start a decent fire..." +
					"What will you do?\n\n" +
					"Press R to Return, Press D to go Downstairs";
		if (Input.GetKeyDown(KeyCode.R)) {
			myState = States.grease_fire_2;
		} else if(Input.GetKeyDown(KeyCode.D)){
			myState = States.downstairs_0;
		}
	}
	
	void grease_fire_1 () {
		text.text = "You rifle through the straw searching for anything useful." + 
					"Something squishy meets your fingers, and you hurriedly push " +
					"the straw aside. You've found a container of grease. It should go " +
					"well with the torch. " +
					"What do you do?\n\n" +
					"Press R to Return, or D to go Downstairs ";
		if (Input.GetKeyDown(KeyCode.R)) {
			myState = States.grease_fire_2;
		} else if(Input.GetKeyDown(KeyCode.D)){
			myState = States.downstairs_0;
		}
	}
	
	void grease_fire_2 () {
		text.text = "You walk to the door with your torch in one hand and the grease " + 
					"in the other. Using the grease you lather up the area around the " +
					"door handle. Then you set the grease aflame. " +
					"You wait for the fire to burn through the wood, and then you " +
					"kick the handle through. The door swings open. " +
					"You can go left or right. What will you choose?\n\n" +
					"Press L to go Left, R to go Right";
		if (Input.GetKeyDown(KeyCode.L)) {
			myState = States.left;
		} else if(Input.GetKeyDown(KeyCode.R)){
			myState = States.right;
		}
	}
	
	void left () {
		text.text = "You walk down the left side of the cooridor. The further you " + 
					"go the more you can see. There's an open door at the end of " +
					"the path. Sounds from the outside filter in. Birds chirping, " +
					"people laughing, dogs barking.\n\n" +
					"You burst into tears and a smile comes to your lips. " +
					"Suddenly you begin to run just as hard as you can. You're " +
					"so close to freedom. And then it hits you. " +
					"The pain is unbearable. You collapse in a heap and squeeze " +
					"your eyes shut.\n\n" +
					"There's laughter behind you. Maniacal devilish laughter." +
					"You turn your body as best as you can to get a glimpse " +
					"at the clown standing over you. He smiles and nods at " +
					"your side. You look and see the white ribs poking out.\n\n " +
					"The clown honks his nose and laughs. " +
					"You're going to die.\n\n" +
					
					"Press R to Restart";
		if (Input.GetKeyDown(KeyCode.R)) {
			myState = States.cell;
		}
	}
	
	void right () {
		text.text = "You shuffle down the right side of the cooridor. The  " + 
					"temperature becomes cooler as you go. The dark hall " +
					"becomes lighter. A flight of stairs appears before you. " +
					"You cautiously ascend. There is a rush of cool air.\n\n" +
					"There is an iron door that has been bashed in at the " +
					"top of the stairs. There are deep gouges in the metal " +
					"and the trail of claws. Your heart pounds. It feels " +
					"like it is going to leap from your chest.\n\n" +
					"Suddenly you hear flapping feet and laughter." +
					"You pull hard on the door handle. Looking back as you " +
					"pull you can see glowing eyes and the outline of an " +
					"inhuman smile. You tug at the handle with all you've got.\n\n" +
					"It gets closer. And closer. You pull over, and over." +
					"The door gives with a low creak. There's barely enough " +
					"room for you to squeeze through slowly. The door won't move " +
					"any further. The flapping feet have stopped moving. " +
					"behind you one last time. He's there. Just a couple steps " +
					"below you. The clown honks his nose and laughs revealing " +
					"sharp white teeth.\n\n" +
					"You start thinking that you're going to die, but you " +
					"hurriedly push yourself into the opening you created, " +
					"hoping that somehow you'll get away. You squirm, and " +
					"wriggle and you start to see the outside. And then..." +
					"It grabs your leg. You're half way through." +
					"You alternate between pulling your leg and kicking, " +
					"but the clown just continues to laugh and pull back.\n\n" +
					"And then you remember your shiv. You pull it from your " +
					"free boot and stab hard behind you. There's a grunt, and " +
					"a thud. " +
					"You did it! You killed the beast. It lets go of your leg, " +
					"and squeeze all the way out of the door way and " +
					"into the light. You are finally free..." +
				
					"Press R to Restart";
		if (Input.GetKeyDown(KeyCode.R)) {
			myState = States.cell;
		}
	}
}